/**
 * Created by bassem on 10/21/16.
 */
module.exports = {
  secretKey: '12345-67890-09876-54321', // used for generating JWT tokens.
  mongodbUrl: 'mongodb://mongo:27017/bookAPI',
};
