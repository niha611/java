export enum EventName {
  COLLAB_PAGE_UPDATED = 'collab.page.updated',
}