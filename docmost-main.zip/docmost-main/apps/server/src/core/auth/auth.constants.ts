export enum UserTokenType {
  FORGOT_PASSWORD = 'forgot-password',
}
