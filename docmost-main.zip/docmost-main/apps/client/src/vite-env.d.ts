/// <reference types="vite/client" />
declare const APP_VERSION: string
