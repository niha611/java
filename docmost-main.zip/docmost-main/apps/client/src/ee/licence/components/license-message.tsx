export default function LicenseMessage() {
  return <>To unlock enterprise features, please contact sales@docmost.com to purchase a license.</>;
}
