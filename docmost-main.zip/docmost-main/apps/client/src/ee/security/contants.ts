export enum SSO_PROVIDER {
  OIDC = 'oidc',
  SAML = 'saml',
  GOOGLE = 'google',
}