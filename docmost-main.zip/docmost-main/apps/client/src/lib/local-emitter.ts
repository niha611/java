import mitt from "mitt";
const localEmitter = mitt();
export default localEmitter;
